<?php
$adminPass = "questree!!"; // 변경 가능
?>
